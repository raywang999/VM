Implementations of Registers for Clipboard, Macro Recordings
