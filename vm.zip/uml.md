# UML Diagrams 
```plantuml
left to right direction
abstract Command{}
class Normal{
  +count: Integer
  +type: Character
  +data: Character
}
class Movement{
  +count: Integer
  +type: Character
  +seek: Character
}
class ComboNM{
  +normal: Normal
  +movement: Movement
}
class Ex{
  +sentence: String[0..*]
}
class Insert{
  +count: Integer
  +mode: Character
  +sentence: String
}
class Replace{
  +count: Integer
  +sentence: String
}
class SetMode {
  +count: Integer 
  +type: Character
  +clone(): SetMode
}
class CM {
  +movement: Movement
  +clone(): SetMode
}
class Ctrl {
  +count: Integer
  +type: Character
}
class Search {
  +needle: String
  +type: Character
}
class Macro {
  +count: Integer 
  +reg: Character 
  +type: Character
}
SetMode -|> Command
SetMode <|-- CM
Command <|- Normal
Command <|--- Movement
Command <|-- ComboNM
Ctrl ---|> Command
Replace --|> Command 
Insert ---|> Command 
Command <|-- Search
Macro --|> Command
Command <|--- Ex
```
```plantuml 
class Keyboard{
  +next(): void
  +getKeystroke(): Keystroke
}
class Resetable {
  -doReset(): void 
  +reset(): void
}
left to right direction
enum KeyType {
  Esc, Plain, Ctrl, Del, Backspace
}
class Keystroke {
  +count: Integer
  +data: Character
}
abstract "Subject<KeyStroke, KeystrokeSource>"{
  +attach(consumer: KeystrokeConsumer*): void
  +notifyAll(): void
}
abstract KeystrokeSource{
  {abstract}+getKeystroke(): Keystroke
}
Keystroke "1" *-- KeyType
Keyboard "1" *-- Keystroke
Keyboard -|> KeystrokeSource 
abstract KeystrokeConsumer{
  {abstract}+consume(key: Keystroke): void
  {abstract}+notify(source: KeystrokeSource*): void
}
KeystrokeSource "0..*" o---|> KeystrokeConsumer
abstract Mode{}
abstract CommandParser{ }
class NormalParser {
  -doReset(): void
  +getNormal(): Normal
}
class MovementParser {
  -doReset(): void
  +getMovement(): Movement
}
class ModeManager{
  +consume(key: Keystroke): void
  +notify(source: KeystrokeSource*): void
}
enum ModeType{
  Normal, Insert, Replace, Ex
}
ModeType "1" -* ModeManager
class Mode {
  +consume(key: Keystroke): void
}
ModeManager "0..*" o- Mode 
KeystrokeConsumer <|-- ModeManager
abstract CommandSource{
  +notifyAll(): void
  +attach(runner: CommandRunner*): void
}
KeystrokeConsumer --o "0..*" Mode 
abstract CommandRunner{
  {abstract}+run(command: Command*): void
  +notify(source: CommandSource*): void
}
KeystrokeSource -|> "Subject<KeyStroke, KeystrokeSource>"
abstract BaseCommandParser
BaseCommandParser <|- CommandParser
CommandParser -|> CommandSource
Resetable <|-- BaseCommandParser
KeystrokeConsumer <|- BaseCommandParser
CommandSource "0..*" o- CommandRunner
MovementParser --|> CommandParser
CommandRunner <|-- NormalRunner 
MovementRunner --|> CommandRunner 
class InsertReflector {
  +consume(key: Keystroke): void
}
KeystrokeConsumer <|-- InsertReflector 
CommandParser <|-- NormalParser
```
```plantuml 
left to right direction
class SetModeRunner{}
abstract Window{}
abstract CommandParser{
  {abstract}-doReset(): void
  {abstract}-parse(key: Keystroke): Boolean
  +reset(): void
  +consume(key: Keystroke): void
}
abstract CommandRunner {
  +{abstract}run(command: Command*): void
  +notify(source: CommandSource*): void
}
CommandParser "0..*" o- CommandRunner
class NormalParser {
  -doReset(): void
  -parse(key: Keystroke): Boolean
  +getNormal(): Normal
}
class MacroParser {
  -doReset(): void
  -parse(key: Keystroke): Boolean
  +getMacro(): Macro
}
class MacroRunner {
  -registers: map<Character, KeyStroke[0..*]>
  +run(command: Command*): void
}
class NormalRunner {
  +run(command: Command*): void
}
class MovementRunner{}
MovementRunner --|> CommandRunner
MovementRunner -o ComboNMRunner 
CommandRunner <|-- NormalRunner 
NormalParser -|> CommandParser 
CommandRunner <|-- SetModeRunner
MacroParser --|> CommandParser 
MovementRunner "1" o-- Window
InsertParser -"resets" SetModeRunner 
SetModeRunner "resets" -- ReplaceParser
SetModeRunner "resets" -- ExParser
CommandParser <|-- InsertParser
CommandParser <|-- ExParser
CommandParser <|-- ReplaceParser
MacroRunner --|> CommandRunner
Window "1"--o NormalRunner
ModeManager --o MacroRunner 
ComboNMRunner --|> CommandRunner
class HistoryManager {
  -map<String, HistoryTree> trees

}
class HistoryTree {
  +push(Tab* tab): void
  +undo(): bool
  +redo(): bool
}
HistoryTree "manages" <-- HistoryManager
NormalRunner o- HistoryManager
ExRunner --|> CommandRunner
RootStatus "1"--o ExRunner
class ComboNMRunner{}
```
```plantuml
left to right direction
abstract LinedFilebuf{}
class TabManager {
  +nextTab(): void
  +currTab(): Tab
  +prevTab(): void
}
Window "1" *--> TabManager
abstract Window{
  -parent: Window*
  -children: Window*[0..*]
  +splitVert(): Boolean
  +splitHori(): Boolean
  +delete(child: Window*)
}
enum WindowType{
  VertSplit, HoriSplit, NoSplit
}
class Tab{
  +getTopLine(): Integer
}
Tab "1" o-- LinedFilebuf
Tab "1" *- Cursor
TabManager "1..*" *-- Tab
Window "1" *- WindowType
class NCWindow{
  +render(): void
}
NCWindow -|> Window
NCWindow "1" *-- Textbox
Textbox "1" o-- StyleManager
class Textbox{
  +render(): void
}
abstract TextStyler{
  {abstract}+getStyles(first: Integer, last: Integer): Style[0..*]
}
class StyleManager{
  +getStylers(filename: String): TextStyler[0..*]
}
StyleManager "0..*" *-- TextStyler
NCWindow "1" *-- StatusBar
class StatusBar{
  +render(): void
}
struct Style{
  first: Integer, 
  last: Integer, 
  attribute: Integer
}
Style "0..*"-* TextStyler 
abstract class LinedFilebuf{
  {abstract}+erase(line: Integer, start: Integer, len: Integer): void
  {abstract}+insert(line: Integer, start: Integer, chars: String): void
  {abstract}+eraseLines(line: Integer, len: Integer): void
  {abstract}+insertLines(line: Integer, len: Integer): void
  {abstract}+begin(): Iterator
  {abstract}+end(): Iterator
}
StatusBar "reads" --> ModeManager
StatusBar "reads" -> TabManager
class FileManager{
  +open(filename: String): LinedFilebuf* 
}
LinedFilebuf "0..*" -* FileManager 
```
```plantuml
left to right direction
abstract Window{ }
class Tab{
  +getTopLine(): Integer
}
abstract Renderable{
  {abstract}+render(): void
}
class NCWindow{
  +render(): void
}
Translateable <|-- Cursor
NCWindow "1" *- Textbox
RenderableBox <|-- StatusBar 
RenderableBox <|-- Textbox
StatusBar "1" -* NCWindow
class StatusBar{}
abstract Resizeable{
  -height: Integer 
  -width: Integer
  +resize(h: Integer, w: Integer)
}
abstract Translateable{
  -toprow: Integer
  -leftcol: Integer
  +transform(r: Integer, c: Integer)
}
class StatusBar{
  +render(): void
}
class Textbox{
  +render(): void
}
abstract RenderableBox{}
RenderableBox --|> Resizeable 
Translateable <|- RenderableBox
RenderableBox -|> Renderable
Window <|-- NCWindow 
RenderableBox <|-- Window 
Resizeable <|-- Tab
```