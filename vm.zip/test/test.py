for i in range(0,10000): 
    print(str(i)+20*"aaaaaaaaab")

