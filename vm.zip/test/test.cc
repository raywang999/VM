#include <memory>
#include <vector>

using namespace std;

struct C{ 
	virtual ~C() =0;
};
C::~C(){}
struct D: public C{};
struct E{
	vector<unique_ptr<C>> v;
};

int main(){
	D d;
	const D* dp = &d;
	E e{};
	for (const auto& p: e.v){
		*p;
	}
}
