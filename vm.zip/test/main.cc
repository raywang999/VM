#include <ranges> 
#include <vector>
#include <string>

struct A{ };
struct B: public A{ int i;};
struct E: public B{};

struct C{
  virtual A* get() =0;
};
struct D: public C{
  B a = B{1};
  virtual B* get() override {return &a;}
};

struct T: public class {
  void get(){};
};

int main(){
  D d{};
  d.get();
}

