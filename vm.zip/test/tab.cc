#include "tab.h"


Cursor Tab::getCursor() const {
  auto col = cursor.getCol();
  auto row = cursor.getRow();
  const int linecnt = filebuf->countLines();
  if (linecnt == 0){
    // file is empty, set cursor to 0,0
    col = row = 0;
    return cursor;
  }
  // o.w., file is not empty
  // ensure cursor's row is 0 <= row < linecnt
  row = min(row,linecnt-1);
  // ensure 0 <= col <= size of line
  col = min(col, filebuf->getLine(row).size());
  col = std::max(0,col);
  return cursor;
}
// moves the cursor dr rows and dc cols over
// prevents cursor from going out of screen
void Tab::moveCursor(int dr, int dc) noexcept{
  // no op if the file is empty
  if (filebuf->countLines() == 0) {return;}
  auto& col = cursor.getCol();
  auto& row = cursor.getRow();
  col += dc; row += dr;
  row = min(row,filebuf->countLines()-1);
  row = std::max(row,0);
  // 0 <= col <= col size in the new row
  col = min(col,filebuf->getLine(row).size());
}
  // moves the cursor dr rows and dc cols over
  // prevents cursor from going out of screen
  // moves the Topline as required
  void move(int dr, int dc) noexcept;
  size_t getTopLine() const noexcept {
    // TODO
    return 0;
  }
};
